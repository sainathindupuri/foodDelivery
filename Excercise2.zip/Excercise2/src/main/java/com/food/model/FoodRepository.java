package com.food.model;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("food")
public interface FoodRepository extends CrudRepository<Food,Integer> {
	
	@Query("from Food f where f.name=:name")
	Food findByName(@Param("name") String name);


}
