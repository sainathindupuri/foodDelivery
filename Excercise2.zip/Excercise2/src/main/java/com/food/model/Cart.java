package com.food.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Cart")
public class Cart {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

//	@OneToOne
//	private Food food;
	private int cost;
//	private int quantity;
	@ElementCollection
	@MapKeyColumn(name = "food")
	@Column(name = "quantity")
	@CollectionTable(name = "CartItems")
	private Map<Food, Integer> cartFood = new HashMap<Food, Integer>();
	private String userId;


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Map<Food, Integer> getCartFood() {
		return cartFood;
	}

	public void setCartFood(Map<Food, Integer> cartFood) {
		this.cartFood = cartFood;
	}

	

	public Cart(int id, int cost, Map<Food, Integer> cartFood, String userId) {
		super();
		this.id = id;
		this.cost = cost;
		this.cartFood = cartFood;
		this.userId = userId;
	}

	public Cart() {
		super();
	}

//	public Cart(int id, Food food, int cost, int quantity) {
//		super();
//		this.id = id;
//		this.food = food;
//		this.cost = cost;
//		this.quantity = quantity;
//	}

//	public Food getFood() {
//		return food;
//	}
//
//	public void setFood(Food food) {
//		this.food = food;
//	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

//	public int getQuantity() {
//		return quantity;
//	}
//
//	public void setQuantity(int quantity) {
//		this.quantity = quantity;
//	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
