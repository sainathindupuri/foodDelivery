package com.food.service;

import java.util.List;
import java.util.Set;

import com.food.model.Cart;
import com.food.model.Food;

public interface foodService {

	List<Food> getFoodList();

	String addToCart(Food food,String userId);

//	List<Cart> getCartList();

	void deleteFromCart(Integer id);

	Integer totalCost(String userId);

	List<Food> getCartList(String userId);

	String checkout(String userId);

}
