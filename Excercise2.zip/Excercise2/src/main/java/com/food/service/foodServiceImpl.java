package com.food.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.model.Cart;
import com.food.model.CartRepository;
import com.food.model.Food;
import com.food.model.FoodRepository;

@Service("service")
public class foodServiceImpl implements foodService {

	@Autowired
	FoodRepository foodRepository;

	@Autowired
	CartRepository cartRepository;

	@Override
	@Transactional
	public List<Food> getFoodList() {
		// TODO Auto-generated method stub
		List<Food> foodList = (List<Food>) foodRepository.findAll();
		return foodList;
	}

	@Override
	@Transactional
	public String addToCart(Food food, String userId) {
		// TODO Auto-generated method stub
		int id = food.getItem_id();
		System.out.println("food is is " + food.getItem_id());
		int flag = 0;
		System.out.println("quantity is" + food.getQuantity());

//		List<Cart> cartList=(List<Cart>)cartRepository.findAll();
//		for (Cart cart : cartList) {
//			if (cart.getFood().getItem_id() == id) {
//				int quantity = cart.getQuantity() + food.getQuantity();
//				int cost = (food.getPrice()) * quantity;
//				cart.setCost(cost);
//				cart.setQuantity(quantity);
//				cartRepository.save(cart);
//				flag = 1;
//				break;
//			}
//		}
//		if (flag == 0) {
//			Cart cart = new Cart();
//			int cost = food.getPrice() * food.getQuantity();
//			Food selectedFood = foodRepository.findOne(id);
//			cart.setCost(cost);
//			cart.setQuantity(selectedFood.getQuantity());
//			cart.setFood(selectedFood);
//			cartRepository.save(cart);
//		}
		if (!nameExistsInCart(food, userId)) {
			addCart(food,userId);
//			System.out.println("added");
//			Food oldfood = foodRepository.findOne(id);
//			Cart cart = cartRepository.findCartItemByUserid(userId);
//			if (cart == null) {
//				Cart cartNew = new Cart();
//				cartNew.setUserId(userId);
//				Map<Food, Integer> cartFood = cartNew.getCartFood();
//				cartFood.put(oldfood, food.getQuantity());
//				cartRepository.save(cartNew);				
//			} else {
//				Map<Food, Integer> cartFood = cart.getCartFood();
//				cartFood.put(oldfood, food.getQuantity());
//				cartRepository.save(cart);
//			}
			
			return "Added to Cart";
		} else {
			System.out.println("update");
			updateCart(food, userId);
//			Food oldFood = foodRepository.findOne(food.getItem_id());
//			Cart cart = cartRepository.findCartItemByUserid(userId);
//			Map<Food, Integer> cartFood = cart.getCartFood();
//			for (Map.Entry<Food, Integer> entry : cartFood.entrySet()) {
//				if (entry.getKey().getItem_id() == food.getItem_id()) {
//					int oldQuantity = entry.getValue();
//					entry.setValue(oldQuantity + food.getQuantity());
//				} else {
//					cartFood.put(food, food.getQuantity());
//				}
//			}
//			cartRepository.save(cart);

		}
		return "Added to Cart";
	}
	
	@Transactional
	public void addCart(Food food,String userId) {
		System.out.println("adding to cart");
		int id = food.getItem_id();
		Food oldfood = foodRepository.findOne(id);
		Cart cart = cartRepository.findCartItemByUserid(userId);
		if (cart == null) {
			Cart cartNew = new Cart();
			cartNew.setUserId(userId);
			Map<Food, Integer> cartFood = cartNew.getCartFood();
			cartFood.put(oldfood, food.getQuantity());
			cartRepository.save(cartNew);				
		} else {
			Map<Food, Integer> cartFood = cart.getCartFood();
			cartFood.put(oldfood, food.getQuantity());
			cartRepository.save(cart);
		}
		
	}
	
	@Transactional
	public void updateCart(Food food,String userId) {
		System.out.println("updating Cart");
		Food oldFood = foodRepository.findOne(food.getItem_id());
		Cart cart = cartRepository.findCartItemByUserid(userId);
		Map<Food, Integer> cartFood = cart.getCartFood();
		for (Map.Entry<Food, Integer> entry : cartFood.entrySet()) {
			if (entry.getKey().getItem_id() == food.getItem_id()) {
				int oldQuantity = entry.getValue();
				entry.setValue(oldQuantity + food.getQuantity());
			} else {
				continue;
			}
		}
		cartRepository.save(cart);

		
	}

//	@Override
//	@Transactional
//	public List<Cart> getCartList() {
//		// TODO Auto-generated method stub
//		List<Cart> cartList=(List<Cart>)cartRepository.findAll();
//		return cartList;
//		
//	}

	@Override
	@Transactional
	public void deleteFromCart(Integer id) {
		cartRepository.delete(id);
	}

	@Override
	@Transactional
	public Integer totalCost(String userId) {
		// TODO Auto-generated method stub
		int price = 0;

		Cart cart = cartRepository.findCartItemByUserid(userId);
		if (cart == null) {
			return 0;
		}
		Map<Food, Integer> cartFood = cart.getCartFood();
		for (Map.Entry<Food, Integer> entry : cartFood.entrySet()) {
			price = price + (entry.getKey().getPrice() * entry.getValue());
		}

		return price;

	}

	@Override
	public List<Food> getCartList(String userId) {
		// TODO Auto-generated method stub
		List<Food> foodList = new ArrayList<Food>();
		Cart cart = cartRepository.findCartItemByUserid(userId);
		if (cart == null) {
			return null;
		} else {
			System.out.println(cart.getCartFood());
			Map<Food, Integer> cartFood = cart.getCartFood();
			for (Map.Entry<Food, Integer> entry : cartFood.entrySet()) {
				Food food = new Food();
				food.setQuantity(entry.getValue());
				food.setPrice(entry.getValue() * entry.getKey().getPrice());
				food.setName(entry.getKey().getName());
				food.setImage(entry.getKey().getImage());
				food.setItem_id(entry.getKey().getItem_id());
				foodList.add(food);
				System.out.println(entry.getKey().getItem_id());
			}
		}
		return foodList;

	}

	@Transactional
	public boolean nameExistsInCart(Food food, String userId) {
		boolean result = false;
		Cart cart = cartRepository.findCartItemByUserid(userId);
		if (cart == null) {
			result = false;
		} else {
			Map<Food, Integer> cartFood = cart.getCartFood();
			for (Map.Entry<Food, Integer> entry : cartFood.entrySet()) {
				if (entry.getKey().getItem_id() == food.getItem_id()) {
					result = true;
				}
			}
		}

		return result;
	}

	@Override
	@Transactional
	public String checkout(String userId) {
		// TODO Auto-generated method stub
		Cart cart = cartRepository.findCartItemByUserid(userId);
		cart.getCartFood().clear();
		cartRepository.save(cart);
		return "Order Placed Successfully";
	}

}
