package com.food.controller;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.food.model.Cart;
import com.food.model.Food;
import com.food.service.foodService;

import io.jsonwebtoken.Jwts;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Cart")
public class cartController {

	@Autowired(required = true)
	public foodService service;

	@GetMapping()
	public List<Food> showCart(Model model, HttpServletRequest request) {
//		List<Cart> cartList = service.getCartList();
//		model.addAttribute("cartList", cartList);
//		return cartList;
		final String authHeader = (request.getHeader("Authorization"));

		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		List<Food> foodList = service.getCartList(userId);
		return foodList;

	}

	@GetMapping("/totalCost")
	public Integer totalCost(HttpServletRequest request) {
		final String authHeader = (request.getHeader("Authorization"));
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		Integer totalCost = service.totalCost(userId);
		return totalCost;
	}

	@RequestMapping(value = "/deleteFromCart")
	public String deleteFromCart(Model model, HttpServletRequest request) {
		Integer id = Integer.parseInt(request.getParameter("id"));
		System.out.println(request.getParameter("id"));
		service.deleteFromCart(id);
		return "redirect:/showCart";
	}

	@PostMapping()
	public ResponseEntity<String> addToCart(@RequestBody Food food, HttpServletRequest request) {
		ResponseEntity<String> responseEntity;
		String response = "";
		System.out.println("selected food item is" + food.getName());
		final String authHeader = (request.getHeader("Authorization"));
		System.out.println(authHeader);
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		response = service.addToCart(food, userId);
		responseEntity = new ResponseEntity<String>(response, HttpStatus.OK);
		return responseEntity;
	}

	@DeleteMapping()
	public ResponseEntity<?> checkout(HttpServletRequest request) {
		final String authHeader = (request.getHeader("Authorization"));
		System.out.println(authHeader);
		final String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		ResponseEntity<String> responseEntity;
		String response = service.checkout(userId);
		responseEntity = new ResponseEntity<String>(response, HttpStatus.OK);
		return responseEntity;
	}

}
