package com.food.controller;

import java.util.ArrayList;
import java.util.List;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.food.model.Food;
import com.food.service.foodService;

@RunWith(SpringRunner.class)
@WebMvcTest(cartController.class)
@ContextConfiguration(classes=com.food.applicationTest.class)
public class cartControllerTest {
	
	@Autowired
	private transient MockMvc mvc;

	@InjectMocks
	private cartController controller;
	
	@MockBean
	private transient foodService service;
	
	private transient Food food;
	
	static List<Food> foodList;
	
	@Before
	public void setUp() {
		
		MockitoAnnotations.initMocks(this);
		mvc=MockMvcBuilders.standaloneSetup(controller).build();
		foodList=new ArrayList<Food>();
		food=new Food("burger", 100, 20);
		foodList.add(food);
		food=new Food("biryani", 200, 10);
		foodList.add(food);		

	}
	
	@Test
	public void testShowCart() throws Exception {
		String token="eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiIxIiwiaWF0IjoxNTU0NzE5MTQ4fQ.q0XEzlHklFr02jroj5zzHq3uXgP3eU9Hr0NItvs4wkr8RmSPiCnMX-3NIWtKQQw1";
		when(service.getCartList("1")).thenReturn(foodList);
		mvc.perform(get("/Cart").header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
		verify(service,times(1)).getCartList("1");
		verifyNoMoreInteractions(service);
	}
	
}
