package com.food.controller;

public class foodControllerTest {

}
