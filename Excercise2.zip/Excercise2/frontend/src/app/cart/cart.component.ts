import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { foodService } from '../services/foodService'

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private router: Router, private foodService: foodService) { }
  cart_List: Array<any>;
  total_Price: number;
  message: String=null;



  ngOnInit() {
    this.foodService.getCart().subscribe(data => {
      this.cart_List = data;
      console.log(this.cart_List);
    });
    this.foodService.getTotalCost().subscribe(data => {
      this.total_Price = data;
      console.log(this.total_Price);
    });
    error=>console.log(error);
    
  }

  checkout() {
    this.foodService.checkout().subscribe(data => {
      this.message = (data['message']);
      console.log(this.message);
    });
    this.router.navigate(['/success']);
    
    
  }

}
