import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { Navbar1Component } from './navbar1/navbar1.component';
import { CartComponent } from './cart/cart.component';
import { RegisterationComponent } from './registeration/registeration.component';
import { AuthService } from './services/auth.service';
import { AuthGuardService } from './services/auth-guard.service';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { foodService } from './services/foodService';
import { HttpClientModule } from '@angular/common/http';
import {TokenInterceptorService} from './token-interceptor.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { SuccessComponent } from './success/success.component'; 



@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    MenuComponent,
    Navbar1Component,
    CartComponent,
    RegisterationComponent,
    SuccessComponent,
     
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  exports:[
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  providers: [
    AuthService,    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    },
    AuthGuardService,
    foodService
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
