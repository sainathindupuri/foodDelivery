import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import {User} from '../User';

@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent implements OnInit {
  isValidFormSubmitted = false;
  val: boolean = false;
  exists: boolean = false;
  message: String;
  user= new User();

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit() {
  }

  save() {
    this.authService.registerUser(this.user)
      .subscribe(data => { if (data) { this.router.navigate(['/login']); } }, error => {
        if (error = "Already Exists") {
          this.exists = true;
          this.message = "User already exists";
          this.router.navigate(['/register']);
          setTimeout(function () {
            this.exists = false;
          }.bind(this), 3000);
        }
      }
      );

  }

  onFormSubmit(form: NgForm) {

    if (form.invalid) {
      return;
    }
    this.save();
    this.user = form.value;
    this.user = new User();
    form.resetForm();
  }

}
