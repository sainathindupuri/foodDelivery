import { Component, OnInit, Injectable } from '@angular/core';
import { items } from '../item_list';
import { item } from '../item';
import { foodService } from '../services/foodService'
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  item_list: Array<any>;
  item: any;
  inputNumber: Array<any>;
  val: Number;
  message: String = null;


  constructor(private router: Router, private foodService: foodService) {
    this.inputNumber = new Array<Number>(40);
    console.log("ghg");
  }


  ngOnInit() {
    this.foodService.getAll().subscribe(data => {
      this.item_list = data;
      console.log(this.item_list);
      this.inputNumber.fill(0);
      // console.log(this.inputNumber);

    });





  };
  addToCart(selectedItem: any) {
    if (this.inputNumber[selectedItem.item_id] > 0) {
      selectedItem.quantity = this.inputNumber[selectedItem.item_id];
      this.item = selectedItem;
      console.log(this.item);
      this.foodService.addToCart(this.item).subscribe(
        data => {
          
        }
        
      );
      this.message=null;

    }
    else {
      this.message = "Select atleast one quantity";
    }
    //  alert("Item added to cart successfully");
  }
  increment(selectedItem: any) {
    console.log(selectedItem);
    console.log(this.inputNumber[selectedItem.item_id]);
    this.val = this.inputNumber[selectedItem.item_id] + 1;
    this.inputNumber[selectedItem.item_id] = this.val;

  }
  decrement(selectedItem: any) {
    console.log(selectedItem);
    console.log(this.inputNumber[selectedItem.item_id]);
    if (this.inputNumber[selectedItem.item_id] > 0) {
      this.val = this.inputNumber[selectedItem.item_id] - 1;
      this.inputNumber[selectedItem.item_id] = this.val;
    }

  }
}
