import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class foodService {


    constructor(private http: HttpClient) {
        console.log("foodService");
    }
    getAll(): Observable<any>{
        return this.http.get('http://localhost:8080/Items');
    }
    getCart(): Observable<any>{
        return this.http.get('http://localhost:8080/Cart');
    }
    addToCart(item:any){
        return this.http.post('http://localhost:8080/Cart',item,{responseType: 'text'});
    }

    getTotalCost(): Observable<any>{
        return this.http.get('http://localhost:8080/Cart/totalCost');
    }
    checkout():Observable<any>{
        return this.http.delete('http://localhost:8080/Cart',{responseType: 'text'});
    }

}