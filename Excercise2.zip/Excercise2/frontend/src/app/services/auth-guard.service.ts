import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuardService implements CanActivate{
  constructor(private authService: AuthService, private router: Router) { }
  canActivate() {

    if(!this.authService.isTokenExpired(this.authService.getToken())) {
      console.log(("token not expired"));
      console.log("hh");
      return true;
    }
    this.router.navigate(['/login']);
    return false;
  }
}
