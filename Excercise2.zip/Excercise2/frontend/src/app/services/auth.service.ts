import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import { User } from '../User';
import { USERS } from '../mock-users';
import { HttpClient } from '@angular/common/http';
import * as jwt_decode from 'jwt-decode';

let usersObservable = Observable.of(USERS);

export const TOKEN_NAME:string = "jwt_token";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  token:string;
  decoded:any;
  constructor(private http: HttpClient) { }

  registerUser(newUser) {
    const url = 'http://localhost:8082/user/registerUser';
    return this.http.post(url, newUser, {responseType: 'text'});
  }

  loginUser(user):Observable<any> {
    const url = 'http://localhost:8082/user/loginUser';
    return this.http.post(url, user);
  }

  setToken(token:string) {
    return localStorage.setItem(TOKEN_NAME, token);
  }

  getToken() {
    return localStorage.getItem(TOKEN_NAME);
  }

  deleteToken() {
    return localStorage.removeItem(TOKEN_NAME);
  }

  getTokenExpirationDate(token: string) {
    this.decoded = jwt_decode(token);
    if(this.decoded.exp === undefined) {
      return null;
    }
    const date = new Date(0);
    date.setUTCSeconds(this.decoded.exp);
    return date;

  }

  isTokenExpired(token?: string): boolean {
    if(!token) {
      token = this.getToken();
    }
    if(!token) {
      return true;
    }
    const date = this.getTokenExpirationDate(token);
    if(date === undefined || date === null) {
      return false;
    }
    return !(date.valueOf() > new Date().valueOf());
  }

}

