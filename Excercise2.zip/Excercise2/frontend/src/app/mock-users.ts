import { User } from './User';

export const USERS: User[] = [
    {id: 1, username: 'sai', password:'sai', email: 'abc@gmail.com'}
];