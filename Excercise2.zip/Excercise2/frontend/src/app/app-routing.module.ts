import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { Navbar1Component } from './navbar1/navbar1.component';
import { CartComponent } from './cart/cart.component';
import { RegisterationComponent } from './registeration/registeration.component';
import { AuthGuardService } from './services/auth-guard.service';
import { SuccessComponent } from './success/success.component'

const routes: Routes = [

  { path: 'login', component: LoginComponent },
  { path: 'menu', component: MenuComponent, canActivate: [AuthGuardService] },
  { path: '', redirectTo: '/menu', pathMatch: 'full' },
  { path: 'cart', component: CartComponent, canActivate: [AuthGuardService] },
  { path: 'registeration', component: RegisterationComponent },
  { path: 'success', component:SuccessComponent, canActivate: [AuthGuardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    BrowserModule,
    FormsModule,],
  exports: [RouterModule]
})
export class AppRoutingModule { }
