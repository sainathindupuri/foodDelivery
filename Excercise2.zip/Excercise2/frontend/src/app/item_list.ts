import {item} from './item';

export const items: item[] =[

    {id:1,name:'Chicken Biryani',price:250,image:'assets/chicken.jpg'},
    {id:2,name:'Chicken Fried Rice',price:200,image:'assets/download.jfif'},
    {id:3,name:'Egg Fried Rice',price:150,image:'assets/egg.jfif'}
]