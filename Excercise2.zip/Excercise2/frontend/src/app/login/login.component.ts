import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup,NgForm } from '@angular/forms';
import { User } from '../User';


@Component({
  selector: 'authentication-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  invalidCredentialMsg : string;
  newUser:User;
  isValidFormSubmitted = false;
  user = new User();
  message:String=null;
  constructor(private service:AuthService,private router:Router) { }

  loginForm =new FormGroup({
    username: new FormControl(),
    password: new FormControl()
  });
  ngOnInit() {
    this.newUser=new User();
  }
  loginUser() {
    console.log("Login user", this.user);
    this.service.loginUser(this.user).subscribe(data => {
      console.log("Login successful");
      if(data['token']) {
        console.log("praneeth");
        this.service.setToken(data['token']);
        console.log(data['token']);
        console.log(this.service.getToken());
        this.router.navigate(['/menu']);
      }
      else{
        console.log(data);
        this.message=(data['message']);

      }
      
    });
  }

  onFormSubmit(form: NgForm) {

    // if (form.invalid) {
    //   return;
    // }
    
    // this.isValidFormSubmitted = true;
   
    this.user = form.value;
    this.loginUser();
    form.resetForm();
  }

  checkMessage()
{
  if(this.message==null)
  {
    return true;
  }
  else
  {
    return false;
  }
}


}
